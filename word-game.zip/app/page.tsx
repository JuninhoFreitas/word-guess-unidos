import WordGame from "@/components/word-game"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-yellow-500 p-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold text-white text-center mb-8 drop-shadow-lg">
          Word Rotation Game
        </h1>
        <WordGame
          sentence="But to the one who does not work but believes in him who justifies the ungodly, his faith is counted as righteousness."
          wordCount={100}
          wordList={[
            "work",
            "believes",
            "him",
            "justifies",
            "ungodly",
            "faith",
            "righteousness",
            "apple",
            "banana",
            "cat",
            "dog",
            "elephant",
            "frog",
            "giraffe",
            "happy",
            "ice",
            "jump",
            "kite",
            "love",
            "moon",
            "nest",
            "orange",
            "purple",
            "queen",
            "rainbow",
            "star",
            "tree",
            "umbrella",
          ]}
        />
      </div>
    </main>
  )
}
