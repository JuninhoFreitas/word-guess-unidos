"use client";

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { animate } from "animejs";
import { useSound } from "use-sound";
import confetti from "canvas-confetti";

interface WordGameProps {
  sentence: string;
  wordCount: number;
  wordList: string[];
}

export default function WordGame({
  sentence,
  wordCount,
  wordList,
}: WordGameProps) {
  const [gameWords, setGameWords] = useState<string[]>([]);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [isRotating, setIsRotating] = useState(true);
  const [result, setResult] = useState<"correct" | "incorrect" | null>(null);
  const [intervalSpeed, setIntervalSpeed] = useState(1000); // 1 second default
  const wordBlockRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Sound effects
  const [playTick] = useSound("/sounds/tick.mp3", { volume: 0.5 });
  const [playCorrect] = useSound("/sounds/correct.mp3", { volume: 0.7 });
  const [playIncorrect] = useSound("/sounds/incorrect.mp3", { volume: 0.7 });
  const [playButton] = useSound("/sounds/button-click.mp3", { volume: 0.5 });

  // Generate game words
  useEffect(() => {
    // Create a mix of words from the sentence and the provided word list
    const sentenceWords = sentence
      .toLowerCase()
      .replace(/[.,!?;:]/g, "")
      .split(" ");
    const uniqueSentenceWords = [...new Set(sentenceWords)];

    // Ensure we have enough words
    const allAvailableWords = [...wordList];

    // Generate the game words
    const generatedWords: string[] = [];
    for (let i = 0; i < wordCount; i++) {
      // 40% chance to pick a word from the sentence, 60% chance for a random word
      if (Math.random() < 0.4 && uniqueSentenceWords.length > 0) {
        const randomIndex = Math.floor(
          Math.random() * uniqueSentenceWords.length
        );
        generatedWords.push(uniqueSentenceWords[randomIndex]);
      } else {
        const randomIndex = Math.floor(
          Math.random() * allAvailableWords.length
        );
        generatedWords.push(allAvailableWords[randomIndex]);
      }
    }

    setGameWords(generatedWords);
  }, [sentence, wordCount, wordList]);

  // Word rotation logic
  useEffect(() => {
    if (isRotating && gameWords.length > 0) {
      intervalRef.current = setInterval(() => {
        setCurrentWordIndex((prevIndex) => {
          const nextIndex = (prevIndex + 1) % gameWords.length;
          playTick();
          animateWordChange();
          return nextIndex;
        });
      }, intervalSpeed);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRotating, gameWords, intervalSpeed, playTick]);

  // Animation for word change
  const animateWordChange = () => {
    if (wordBlockRef.current) {
      animate(wordBlockRef.current, {
        scale: [1, 1.1, 1],
        rotate: [0, 2, -2, 0],
        duration: intervalSpeed * 0.5,
        easing: "easeInOutQuad",
      });
    }
  };

  // Check if the word is in the sentence
  const checkWord = () => {
    playButton();
    setIsRotating(false);

    const currentWord = gameWords[currentWordIndex];
    const isInSentence = sentence
      .toLowerCase()
      .includes(currentWord.toLowerCase());

    setResult(isInSentence ? "correct" : "incorrect");

    if (isInSentence) {
      playCorrect();
      // Celebration animation
      if (wordBlockRef.current) {
        animate(wordBlockRef.current, {
          scale: [1, 1.2, 1],
          rotate: [0, 5, -5, 0],
          backgroundColor: ["#4ade80", "#22c55e", "#4ade80"],
          duration: 1000,
          easing: "easeInOutQuad",
        });
      }

      // Launch confetti
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    } else {
      playIncorrect();
      // Incorrect animation
      if (wordBlockRef.current) {
        animate(wordBlockRef.current, {
          translateX: [0, -10, 10, -10, 10, 0],
          backgroundColor: ["#f87171", "#ef4444", "#f87171"],
          duration: 500,
          easing: "easeInOutQuad",
        });
      }
    }
  };

  // Reset the game
  const resetGame = () => {
    playButton();
    setIsRotating(true);
    setResult(null);
    // Shuffle the words for more variety
    setGameWords((prevWords) => [...prevWords].sort(() => Math.random() - 0.5));
  };

  // Handle interval speed change
  const handleSpeedChange = (value: number[]) => {
    // Convert to milliseconds (500ms to 2000ms range)
    const newSpeed = 2500 - value[0] * 20;
    setIntervalSpeed(newSpeed);

    // Restart interval with new speed
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    if (isRotating) {
      intervalRef.current = setInterval(() => {
        setCurrentWordIndex((prevIndex) => {
          const nextIndex = (prevIndex + 1) % gameWords.length;
          playTick();
          animateWordChange();
          return nextIndex;
        });
      }, newSpeed);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-xl">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-purple-700 mb-4">
          Find words from the sentence:
        </h2>
        <p className="text-lg bg-purple-100 p-4 rounded-lg border-2 border-purple-300">
          {sentence}
        </p>
      </div>

      <div className="flex flex-col items-center justify-center space-y-8">
        {/* Word display block */}
        <div
          ref={wordBlockRef}
          className={`w-64 h-64 flex items-center justify-center rounded-2xl text-4xl font-bold shadow-lg transition-all ${
            result === "correct"
              ? "bg-green-400 text-white"
              : result === "incorrect"
              ? "bg-red-400 text-white"
              : "bg-yellow-300 text-purple-800"
          }`}
        >
          {gameWords.length > 0 ? gameWords[currentWordIndex] : "Loading..."}
        </div>

        {/* Result display */}
        {result && (
          <div
            className={`text-2xl font-bold ${
              result === "correct" ? "text-green-600" : "text-red-600"
            }`}
          >
            {result === "correct" ? "Correct! 🎉" : "Incorrect! 😢"}
          </div>
        )}

        {/* Game controls */}
        <div className="flex flex-col md:flex-row gap-4 items-center justify-center w-full">
          {isRotating ? (
            <Button
              onClick={checkWord}
              className="bg-red-500 hover:bg-red-600 text-white text-2xl py-8 px-12 rounded-full shadow-lg transform transition hover:scale-105"
            >
              STOP
            </Button>
          ) : (
            <Button
              onClick={resetGame}
              className="bg-blue-500 hover:bg-blue-600 text-white text-xl py-6 px-10 rounded-full shadow-lg transform transition hover:scale-105"
            >
              Play Again
            </Button>
          )}
        </div>

        {/* Speed control */}
        <div className="w-full max-w-md">
          <div className="flex justify-between mb-2">
            <span className="text-sm font-medium">Fast</span>
            <span className="text-sm font-medium">Slow</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-lg">🐇</span>
            <Slider
              defaultValue={[75]}
              max={100}
              step={1}
              onValueChange={handleSpeedChange}
              className="flex-1"
            />
            <span className="text-lg">🐢</span>
          </div>
          <p className="text-center text-sm mt-2">
            Word changes every {(intervalSpeed / 1000).toFixed(1)} seconds
          </p>
        </div>
      </div>
    </div>
  );
}
